# Kombucha ladu + valmistamine — paigaldusjuhend

Kuus faili lähevad Sinu olemasolevasse projekti. Number failinime ees näitab järjekorda.

## 1. Andmebaasi tabelid

Ava `shared/schema.ts` ja lisa selle lõppu kahe faili sisu:

- **1_schema_lisa.ts** — pudelid, sildid, korgid, vaikekorgid, liikumised
- **4_schema_pruulimine.ts** — tee varu ja pruulimised

Mõlemad failid algavad `import`-ridadega. Kui samad read on `schema.ts`-is juba olemas, ära kirjuta neid topelt, vaid lisa ainult puuduvad nimed.

**Üks koht vajab kohandamist:** failis 1 viitab `labelStock.flavorId` Sinu maitsete tabelile. Kood eeldab, et maitse `id` on täisarv. Kui Sinu maitse `id` on hoopis tekst või uuid, muuda real `flavorId: integer("flavor_id")` sõna `integer` sõnaks `text`. Sama kehtib `flavorCapDefault` kohta.

## 2. Serveri marsruudid

- **2_server_inventory.ts** → salvesta `server/inventory.ts`
- **5_server_brews.ts** → salvesta `server/brews.ts`

Mõlema faili ülaosas on kaks importi, mida võib olla vaja kohandada:
- `import { db } from "./db"` — kui Sinu andmebaasi ühendus asub mujal, muuda tee.
- failis 2 `flavors` — kui Sinu maitsete tabel on `schema.ts`-is teise nimega, muuda see nimi. Kui maitse nimi pole veerus `name`, muuda ka `flavors.name`.

Seejärel registreeri marsruudid seal, kus Sul teised marsruudid registreeritakse (tavaliselt `server/routes.ts`, funktsiooni `registerRoutes` sees):

```ts
import { registerInventoryRoutes } from "./inventory";
import { registerBrewRoutes } from "./brews";

registerInventoryRoutes(app);
registerBrewRoutes(app);
```

## 3. Lehed

- **3_client_Ladu.tsx** → salvesta `client/src/pages/Ladu.tsx`
- **6_client_Valmistamine.tsx** → salvesta `client/src/pages/Valmistamine.tsx`

Lisa `client/src/App.tsx`-i Wouteri marsruudid ja menüülingid:

```tsx
import Ladu from "@/pages/Ladu";
import Valmistamine from "@/pages/Valmistamine";

<Route path="/ladu" component={Ladu} />
<Route path="/valmistamine" component={Valmistamine} />
```

Lehed kasutavad `@tanstack/react-query`, mis on Sul juba olemas. Ühtegi uut shadcn komponenti pole vaja paigaldada, stiil on puhas Tailwind.

## 4. Tabelite loomine andmebaasi

Käivita terminalis:

```
npm run db:push
```

Kui sellist skripti pole, käivita `npx drizzle-kit push`. See loob uued tabelid Supabase andmebaasi.

## Valemid pruulimises

Sisestad ainult keema läinud vee. Ülejäänu arvutatakse:

- **Tee, g** = keema läinud L × 5 + 5
- **Suhkur, g** = (keema läinud L + külm vesi L) × 80
- **Juuretis, g** = (keema läinud L + külm vesi L) × 10 × juuretise %

Külm vesi võrdub vaikimisi keema läinud veega, kuid saad selle üle kirjutada. Tee grammid arvatakse salvestamisel valitud tee sordi laost maha. Kui kustutad pruulimise, tuleb tee laoseisu tagasi.
